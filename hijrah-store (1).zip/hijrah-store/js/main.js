// Sample product data (max 5)
const products = [
  {id:1,title:'Hijab Motif Oval - Navy',price:129000,image:'images/product1.jpg'},
  {id:2,title:'Gamis Lucu Kekinian - Pink',price:199000,image:'images/product2.jpg'},
  {id:3,title:'Hijab Syar\'i Premium - Soft Blue',price:149000,image:'images/product3.jpg'},
  {id:4,title:'Gamis Casual - Grey Floral',price:179000,image:'images/product4.jpg'},
  {id:5,title:'Set Hijab + Inner - Comfy',price:219000,image:'images/product5.jpg'}
];

// Render slider
const slider = document.getElementById('product-slider');
function formatRupiah(n){ return 'Rp ' + n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
function renderSlides(){
  slider.innerHTML='';
  products.slice(0,5).forEach(p=>{
    const div = document.createElement('div'); div.className='slide';
    div.innerHTML = `
      <img src="${p.image}" alt="${p.title}">
      <h4>${p.title}</h4>
      <p>${formatRupiah(p.price)}</p>
      <div class="card-actions">
        <button class="btn small" onclick="addToCart(${p.id})">Tambah ke Keranjang</button>
      </div>
    `;
    slider.appendChild(div);
  });
}

// Simple cart using localStorage
let cart = JSON.parse(localStorage.getItem('cart')||'[]');
const cartCountEl = document.getElementById('cart-count');
function updateCartUI(){
  cartCountEl.textContent = cart.reduce((s,i)=>s+i.qty,0);
  localStorage.setItem('cart', JSON.stringify(cart));
}
function addToCart(id){
  const prod = products.find(p=>p.id===id);
  const found = cart.find(c=>c.id===id);
  if(found) found.qty++;
  else cart.push({id:prod.id,title:prod.title,price:prod.price,qty:1});
  updateCartUI();
  alert(prod.title + ' berhasil ditambahkan ke keranjang.');
}

// Checkout
document.getElementById('checkout-btn').addEventListener('click',()=>{
  if(cart.length===0){ alert('Keranjang kosong. Tambahkan produk terlebih dahulu.'); return; }
  // sederhana: tampilkan struk checkout
  let total = cart.reduce((s,i)=>s + i.price * i.qty,0);
  let msg = 'Struk Checkout:\n';
  cart.forEach(i=> msg += `${i.title} x${i.qty} - ${formatRupiah(i.price*i.qty)}\n`);
  msg += '\nTotal: ' + formatRupiah(total) + '\n\nTerima kasih! Silakan hubungi toko untuk pembayaran dan pengiriman.';
  alert(msg);
  // kosongkan keranjang
  cart = []; updateCartUI();
});

// Testimoni (simpan ke localStorage)
const testimoniList = document.getElementById('testimoni-list');
function loadTestimoni(){
  const data = JSON.parse(localStorage.getItem('testimoni')||'[]');
  testimoniList.innerHTML='';
  if(data.length===0){ testimoniList.innerHTML = '<p>Belum ada testimoni. Jadilah yang pertama!</p>'; return; }
  data.forEach(t=>{
    const div = document.createElement('div'); div.className='testimoni-item';
    div.innerHTML = `<strong>${t.nama||'Anonim'}</strong><p>${t.pesan}</p>`;
    testimoniList.appendChild(div);
  });
}

// handle form
document.getElementById('testimoni-form').addEventListener('submit', e=>{
  e.preventDefault();
  const nama = document.getElementById('nama').value.trim();
  const pesan = document.getElementById('pesan').value.trim();
  const data = JSON.parse(localStorage.getItem('testimoni')||'[]');
  data.unshift({nama,pesan});
  localStorage.setItem('testimoni', JSON.stringify(data));
  document.getElementById('testimoni-form').reset();
  loadTestimoni();
  alert('Terima kasih atas testimoni Anda!');
});

// feedback form
document.getElementById('feedback-form').addEventListener('submit', e=>{
  e.preventDefault();
  const nama = document.getElementById('fb-nama').value.trim();
  const pesan = document.getElementById('fb-pesan').value.trim();
  // Simpel: simpan ke localStorage sebagai daftar kritik
  const data = JSON.parse(localStorage.getItem('kritiks')||'[]');
  data.unshift({nama,pesan,ts:Date.now()});
  localStorage.setItem('kritiks', JSON.stringify(data));
  document.getElementById('feedback-form').reset();
  alert('Terima kasih! Kritik & saran Anda sudah terkirim.');
});

// init
renderSlides();
loadTestimoni();
updateCartUI();

// footer year
document.getElementById('year').textContent = new Date().getFullYear();
