# Hijrah Store — Static Website

Website sederhana untuk jualan hijab & gamis. Fitur:
- Slider produk terlaris (maks 5)
- Tambah ke keranjang (localStorage)
- Tombol Checkout (menampilkan struk sederhana)
- Testimoni pelanggan + form input
- Form kritik & saran
- Informasi alamat: Jldipenggori 74, Bogor

Deploy: Upload ke GitHub dan aktifkan GitHub Pages.
